/**
 * Templates Index
 * 
 * This file exports all template components for easier imports.
 */

// Layout templates
export { default as MainLayout } from './MainLayout';