/**
 * Pages Index
 * 
 * This file exports all page components for easier imports.
 */

// Pages
export { default as HomePage } from './HomePage';